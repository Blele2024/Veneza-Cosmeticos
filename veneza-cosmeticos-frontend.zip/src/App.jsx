export default function App() {
  return (
    <div style={{ textAlign: "center", padding: "2rem" }}>
      <h1 style={{ color: "#e67fae" }}>Veneza Cosméticos</h1>
      <p>Loja em construção com carrinho, painel admin e pagamento.</p>
    </div>
  );
}
